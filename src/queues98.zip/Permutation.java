import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

public class Permutation {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        RandomizedQueue<String> randomizedQueue = new RandomizedQueue<String>();

        // input plan 1
        // int n = StdIn.readInt();
        // StdOut.println(n);
        // while (!StdIn.isEmpty()) {
        // StdOut.println("haha");
        // String item = StdIn.readString();
        // StdOut.println(item);
        // randomizedQueue.enqueue(item);
        // }
        int k = Integer.parseInt(args[0]);
        if (k == 0) {
            return;
        }
        for (int i = 0; !StdIn.isEmpty(); i++) {
            String item = StdIn.readString();
            if (i < k) {
                randomizedQueue.enqueue(item);
            } else if (StdRandom.uniform(i + 1) < k) {
                randomizedQueue.dequeue();
                randomizedQueue.enqueue(item);
            }
        }

        // input plan 2
        // String[] a = StdIn.readAllStrings();
        // for (int i = 0; i < a.length; i++) {
        // randomizedQueue.enqueue(a[i]);
        // }

        // StdOut.println(a.length);

        // StdOut.println(randomizedQueue.isEmpty());
        for (int i = 0; i < k; i++) {
            StdOut.println(randomizedQueue.dequeue());
        }
    }

}
